

const fetch_btn=document.getElementById("myBTN");
 

    


fetch_btn.addEventListener(('click'),function getData(){
url="exercise.json";
fetch(url).then((response)=>{

   
    return response.json();

})
.then((data)=>{
    let data1=" ";
    data.map((values)=>{
     data1+=`<div class="info">${values.first_name+"  "+values.last_name}</div>`
    })
   document.getElementById("container").innerHTML=data1;
   



})
 
})

getData();