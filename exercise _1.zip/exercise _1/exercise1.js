let Person={
Name:"Saeedeh Dargahi",
Age:35,
Yourcontactdetails:[{
    Yourphonenumber:075445554444,
    Youremailaddress:"melis.drg86@gmail.com"
}],
Yourphysicaladdress:[{
    Streetname:"gainey",
    Housenumber:15,
    Housename:"cottage"
}],
City:"Chippenham",
Country:"England",
Postcode:"SN15 1OF",
County:"Chippenham"
}
// console.log("My name is:"+" "+Person.Name+" "+"My age is:"+" "+Person.Age);
// console.log(Person.Yourcontactdetails);
// console.log(Person.Yourphysicaladdress);
