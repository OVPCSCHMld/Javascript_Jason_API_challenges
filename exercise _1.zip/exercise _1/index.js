let person={

fname:"Saeedeh",
lname:"Dargahi",
gender:"fmale",
city:"chippenham"

}
// console.log(person.fname)
console.log(person.fname+" "+person.lname)




