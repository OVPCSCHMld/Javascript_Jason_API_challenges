const myObject = {
  someKey: "some value",
  hello: "World",
  js: "javascript foreach object",
}

const arr=Object.entries(myObject);
console.log(arr);