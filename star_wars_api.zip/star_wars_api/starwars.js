



function getData(){
url="https://swapi.dev/api/people";
fetch(url).then((response)=>{

   
    return response.json();

})
.then((data)=>{



    console.log(data.results);
    const data2=data.results;
     
//    let text="";
//    for (let i in data){
//      text+=console.log(data[i]);
//    }






    let data3=" ";
    data.results.map((values)=>{
     data3+=`<div class="info">${values.name+"  "+values.birth_year}</div>`
     document.getElementById("container").innerHTML=data3;

 })
 
})
}

getData();